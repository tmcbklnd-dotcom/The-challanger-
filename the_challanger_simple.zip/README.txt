The Challanger - Simple 3 Page Website

Pages:
1. register.html -> Registration form (redirects to login.html)
2. login.html -> Login form (redirects to deposit.html)
3. deposit.html -> Deposit buttons (direct UPI links)

UPI ID used: 9758587766@fam
